<?php
require '../config/config.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();

header('Content-Type: application/json');

// Modifica la consulta para reflejar la estructura real de la tabla
$sql = $con->prepare("SELECT id, nombre, email FROM clientes");
$sql->execute();
$clientes = $sql->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['clientes' => $clientes]);
?>
