<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

$accion = $_POST['accion'] ?? '';
$id_producto = $_POST['id_producto'] ?? null;
$nombre = $_POST['nombre'] ?? null;
$precio = $_POST['precio'] ?? null;
$descripcion = $_POST['descripcion'] ?? null;
$descuento = $_POST['descuento'] ?? null;

if ($id_producto && in_array($accion, ['eliminar', 'modificar'])) {
    try {
        $db = new Database();
        $con = $db->conectar();

        if ($accion === 'eliminar') {
            // Verificar si el producto existe antes de eliminarlo
            $sql_check = $con->prepare("SELECT id FROM productos WHERE id = ?");
            $sql_check->execute([$id_producto]);
            if ($sql_check->rowCount() > 0) {
                $sql = $con->prepare("DELETE FROM productos WHERE id = ?");
                $sql->execute([$id_producto]);
                echo json_encode(['success' => 'Producto eliminado correctamente']);
            } else {
                echo json_encode(['error' => 'Producto no encontrado']);
            }
        } elseif ($accion === 'modificar') {
            // Verificar si el producto existe antes de modificarlo
            $sql_check = $con->prepare("SELECT id FROM productos WHERE id = ?");
            $sql_check->execute([$id_producto]);
            if ($sql_check->rowCount() > 0) {
                $sql = $con->prepare("UPDATE productos SET nombre = ?, precio = ?, descripcion = ?, descuento = ? WHERE id = ?");
                $sql->execute([$nombre, $precio, $descripcion, $descuento, $id_producto]);
                echo json_encode(['success' => 'Producto modificado correctamente']);
            } else {
                echo json_encode(['error' => 'Producto no encontrado']);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Error al procesar la solicitud: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Datos inválidos']);
}
?>
