<?php
session_start();
require '../config/config.php';
require '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if ($email && $password) {
        $db = new Database();
        $con = $db->conectar();

        $sql = $con->prepare("SELECT id, nombre, email, password, estatus FROM administradores WHERE email = ? AND estatus = 'activo'");
        $sql->execute([$email]);
        $admin = $sql->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_nombre'] = $admin['nombre'];
            header('Location: ../index.html');
            exit;
        } else {
            echo 'Email o contraseña incorrectos, o la cuenta no está activa.';
        }
    } else {
        echo 'Por favor, complete todos los campos.';
    }
}
?>
