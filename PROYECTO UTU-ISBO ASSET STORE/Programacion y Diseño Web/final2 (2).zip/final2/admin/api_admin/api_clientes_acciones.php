<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

$accion = $_POST['accion'] ?? '';
$id_cliente = $_POST['id_cliente'] ?? null;

if ($id_cliente && in_array($accion, ['eliminar', 'banear'])) {
    try {
        $db = new Database();
        $con = $db->conectar();

        if ($accion === 'eliminar') {
            // Verificar si el cliente existe antes de eliminarlo
            $sql_check = $con->prepare("SELECT id FROM clientes WHERE id = ?");
            $sql_check->execute([$id_cliente]);
            if ($sql_check->rowCount() > 0) {
                $sql = $con->prepare("DELETE FROM clientes WHERE id = ?");
                $sql->execute([$id_cliente]);
                echo json_encode(['success' => 'Cliente eliminado correctamente']);
            } else {
                echo json_encode(['error' => 'Cliente no encontrado']);
            }
        } elseif ($accion === 'banear') {
            // Verificar si el cliente ya está baneado
            $sql_check = $con->prepare("SELECT id, estatus FROM clientes WHERE id = ?");
            $sql_check->execute([$id_cliente]);
            $cliente = $sql_check->fetch(PDO::FETCH_ASSOC);

            if ($cliente) {
                if ($cliente['estatus'] === 'baneado') {
                    echo json_encode(['error' => 'El cliente ya está baneado']);
                } else {
                    $sql = $con->prepare("UPDATE clientes SET estatus = 'baneado' WHERE id = ?");
                    $sql->execute([$id_cliente]);
                    echo json_encode(['success' => 'Cliente baneado correctamente']);
                }
            } else {
                echo json_encode(['error' => 'Cliente no encontrado']);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Error al procesar la solicitud: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Datos inválidos']);
}
?>
