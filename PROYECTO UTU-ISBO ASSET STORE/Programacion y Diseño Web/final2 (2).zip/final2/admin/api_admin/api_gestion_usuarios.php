<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

$accion = $_POST['accion'] ?? '';
$id_usuario = $_POST['id_usuario'] ?? null;

// Verificar si la acción es válida y si el ID de usuario es proporcionado
if ($id_usuario && in_array($accion, ['eliminar', 'banear'])) {
    try {
        $db = new Database();
        $con = $db->conectar();

        if ($accion === 'eliminar') {
            // Verificar si el usuario existe antes de eliminarlo
            $sql_check = $con->prepare("SELECT id FROM usuarios WHERE id = ?");
            $sql_check->execute([$id_usuario]);
            if ($sql_check->rowCount() > 0) {
                $sql = $con->prepare("DELETE FROM usuarios WHERE id = ?");
                $sql->execute([$id_usuario]);
                echo json_encode(['success' => 'Usuario eliminado correctamente']);
            } else {
                echo json_encode(['error' => 'Usuario no encontrado']);
            }
        } elseif ($accion === 'banear') {
            // Verificar si el usuario ya está baneado
            $sql_check = $con->prepare("SELECT id, estatus FROM usuarios WHERE id = ?");
            $sql_check->execute([$id_usuario]);
            $usuario = $sql_check->fetch(PDO::FETCH_ASSOC);

            if ($usuario) {
                if ($usuario['estatus'] === 'baneado') {
                    echo json_encode(['error' => 'El usuario ya está baneado']);
                } else {
                    $sql = $con->prepare("UPDATE usuarios SET estatus = 'baneado' WHERE id = ?");
                    $sql->execute([$id_usuario]);
                    echo json_encode(['success' => 'Usuario baneado correctamente']);
                }
            } else {
                echo json_encode(['error' => 'Usuario no encontrado']);
            }
        }
    } catch (Exception $e) {
        echo json_encode(['error' => 'Error al procesar la solicitud: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['error' => 'Datos inválidos']);
}
?>
