<?php
require '../config/config.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();

$sql = $con->prepare("SELECT id, nombre, precio, descuento, descripcion FROM productos");
$sql->execute();
$productos = $sql->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode(['productos' => $productos]);
?>
