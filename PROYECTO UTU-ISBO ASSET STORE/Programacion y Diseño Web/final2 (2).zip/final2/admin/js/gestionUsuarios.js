document.addEventListener("DOMContentLoaded", function () {
    const botonesEliminar = document.querySelectorAll('.btn-eliminar');
    const botonesBanear = document.querySelectorAll('.btn-banear');

    botonesEliminar.forEach(boton => {
        boton.addEventListener('click', function () {
            const idUsuario = this.dataset.id;
            gestionarUsuario(idUsuario, 'eliminar');
        });
    });

    botonesBanear.forEach(boton => {
        boton.addEventListener('click', function () {
            const idUsuario = this.dataset.id;
            gestionarUsuario(idUsuario, 'banear');
        });
    });

    function gestionarUsuario(idUsuario, accion) {
        if (confirm(`¿Está seguro de que desea ${accion} al usuario con ID ${idUsuario}?`)) {
            fetch('../api/api_gestion_usuarios.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ id_usuario: idUsuario, accion: accion })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.success);
                    location.reload();
                } else {
                    alert(data.error);
                }
            })
            .catch(error => console.error('Error:', error));
        }
    }
});
