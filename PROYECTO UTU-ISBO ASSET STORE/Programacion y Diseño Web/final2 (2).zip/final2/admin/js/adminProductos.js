function eliminarProducto(idProducto) {
    if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
        fetch('api_admin/api_productos_acciones.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `accion=eliminar&id_producto=${idProducto}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // Recargar la página para actualizar la lista
            } else {
                alert(data.error);
            }
        })
        .catch(error => console.error('Error al eliminar el producto:', error));
    }
}

function modificarProducto(idProducto, nombre, precio, descripcion) {
    fetch('api_admin/api_productos_acciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `accion=modificar&id_producto=${idProducto}&nombre=${encodeURIComponent(nombre)}&precio=${precio}&descripcion=${encodeURIComponent(descripcion)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.success);
            location.reload(); // Recargar la página para actualizar la lista
        } else {
            alert(data.error);
        }
    })
    .catch(error => console.error('Error al modificar el producto:', error));
}
