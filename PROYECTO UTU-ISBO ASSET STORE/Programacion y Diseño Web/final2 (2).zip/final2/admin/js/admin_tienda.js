document.addEventListener("DOMContentLoaded", function () {
    const clientesContainer = document.querySelector('#clientesActivos');

    fetch('api_admin/api_clientes_activos.php')
        .then(response => response.json())
        .then(data => {
            if (!Array.isArray(data.clientes) || data.clientes.length === 0) {
                clientesContainer.innerHTML = '<tr><td colspan="4" class="text-center">No hay clientes activos.</td></tr>';
                return;
            }

            data.clientes.forEach(cliente => {
                const row = `
                    <tr>
                        <td>${cliente.id}</td>
                        <td>${cliente.nombre}</td>
                        <td>${cliente.email}</td>
                        <td>
                            <button class="btn btn-danger btn-sm" onclick="eliminarCliente(${cliente.id})">Eliminar</button>
                            <button class="btn btn-warning btn-sm" onclick="banearCliente(${cliente.id})">Banear</button>
                        </td>
                    </tr>
                `;
                clientesContainer.innerHTML += row;
            });
        })
        .catch(error => {
            console.error('Error al cargar los clientes:', error);
            alert('Hubo un problema al cargar los clientes.');
        });
});

// Funciones de acción para eliminar o banear clientes
function eliminarCliente(idCliente) {
    if (confirm('¿Estás seguro de que quieres eliminar este cliente?')) {
        fetch('api_admin/api_clientes_acciones.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `accion=eliminar&id_cliente=${idCliente}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // Recargar la página para actualizar la lista
            } else {
                alert(data.error);
            }
        })
        .catch(error => console.error('Error al eliminar el cliente:', error));
    }
}

function banearCliente(idCliente) {
    if (confirm('¿Estás seguro de que quieres banear este cliente?')) {
        fetch('api_admin/api_clientes_acciones.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `accion=banear&id_cliente=${idCliente}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // Recargar la página para actualizar la lista
            } else {
                alert(data.error);
            }
        })
        .catch(error => console.error('Error al banear el cliente:', error));
    }
}

document.addEventListener("DOMContentLoaded", function () {
    const productosContainer = document.querySelector('#productosActivos');

    // Cargar productos activos
    fetch('api_admin/api_productos_activos.php')
        .then(response => response.json())
        .then(data => {
            if (!Array.isArray(data.productos) || data.productos.length === 0) {
                productosContainer.innerHTML = '<tr><td colspan="5" class="text-center">No hay productos activos.</td></tr>';
                return;
            }

            data.productos.forEach(producto => {
                const row = `
                    <tr>
                        <td>${producto.id}</td>
                        <td>${producto.nombre}</td>
                        <td>${producto.precio}</td>
                        <td>${producto.descuento}</td>
                        <td>${producto.descripcion}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="mostrarFormularioEditar(${producto.id}, '${producto.nombre}', ${producto.precio}, ${producto.descuento}, '${producto.descripcion}')">Editar</button>
                            <button class="btn btn-danger btn-sm" onclick="eliminarProducto(${producto.id})">Eliminar</button>
                        </td>
                    </tr>
                `;
                productosContainer.innerHTML += row;
            });
        })
        .catch(error => {
            console.error('Error al cargar los productos:', error);
            alert('Hubo un problema al cargar los productos.');
        });
});

// Funciones de acción para eliminar y editar productos
function eliminarProducto(idProducto) {
    if (confirm('¿Estás seguro de que quieres eliminar este producto?')) {
        fetch('api_admin/api_productos_acciones.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `accion=eliminar&id_producto=${idProducto}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert(data.success);
                location.reload(); // Recargar la página para actualizar la lista
            } else {
                alert(data.error);
            }
        })
        .catch(error => console.error('Error al eliminar el producto:', error));
    }
}

function mostrarFormularioEditar(id, nombre, precio, descuento, descripcion) {
    // Mostrar un formulario para editar los detalles del producto
    const editarFormHTML = `
        <form id="editarProductoForm">
            <div class="mb-3">
                <label for="nombreProducto" class="form-label">Nombre</label>
                <input type="text" class="form-control" id="nombreProducto" value="${nombre}">
            </div>
            <div class="mb-3">
                <label for="precioProducto" class="form-label">Precio</label>
                <input type="number" class="form-control" id="precioProducto" value="${precio}">
            </div>
            <div class="mb-3">
                <label for="descuentoProducto" class="form-label">Descuento (%)</label>
                <input type="number" class="form-control" id="descuentoProducto" value="${descuento}">
            </div>
            <div class="mb-3">
                <label for="descripcionProducto" class="form-label">Descripción</label>
                <textarea class="form-control" id="descripcionProducto">${descripcion}</textarea>
            </div>
            <button type="button" class="btn btn-primary" onclick="editarProducto(${id})">Guardar cambios</button>
        </form>
    `;

    document.querySelector('#formularioEditarProducto').innerHTML = editarFormHTML;
}

function editarProducto(idProducto) {
    const nombre = document.querySelector('#nombreProducto').value;
    const precio = document.querySelector('#precioProducto').value;
    const descuento = document.querySelector('#descuentoProducto').value;
    const descripcion = document.querySelector('#descripcionProducto').value;

    fetch('api_admin/api_productos_acciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: `accion=modificar&id_producto=${idProducto}&nombre=${encodeURIComponent(nombre)}&precio=${precio}&descuento=${descuento}&descripcion=${encodeURIComponent(descripcion)}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(data.success);
            location.reload(); // Recargar la página para actualizar la lista
        } else {
            alert(data.error);
        }
    })
    .catch(error => console.error('Error al editar el producto:', error));
}
