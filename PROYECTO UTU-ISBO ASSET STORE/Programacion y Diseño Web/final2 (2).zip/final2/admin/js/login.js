document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.querySelector('#loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', function (event) {
            event.preventDefault();
            
            const email = document.querySelector('#inputEmail').value;
            const password = document.querySelector('#inputPassword').value;
            
            fetch('api_admin/login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
            })
            .then(response => response.text())
            .then(data => {
                if (data.includes('Location: admin_tienda.html')) {
                    window.location.href = 'admin_tienda.html';
                } else {
                    alert('Email o contraseña incorrectos, o la cuenta no está activa.');
                }
            })
            .catch(error => console.error('Error en la solicitud:', error));
        });
    }
});
