document.addEventListener("DOMContentLoaded", function () {
    // Cargar los productos del carrito desde la API
    fetch('../api/api_cargar_carrito.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error al cargar el carrito');
                return;
            }

            const cartTableBody = document.getElementById('cartTableBody');
            let total = 0;

            data.productos.forEach(producto => {
                const { nombre, subtotal } = producto;
                total += subtotal;

                const row = `
                    <tr>
                        <td>${nombre}</td>
                        <td>${subtotal.toFixed(2)}</td>
                    </tr>
                `;
                cartTableBody.innerHTML += row;
            });

            document.getElementById('total').textContent = `$${total.toFixed(2)}`;
        })
        .catch(error => console.error('Error al cargar el carrito:', error));

    // Configurar PayPal
    paypal.Buttons({
        style: {
            color: 'blue',
            shape: 'pill',
            label: 'pay'
        },
        createOrder: function (data, actions) {
            return actions.order.create({
                purchase_units: [{
                    amount: {
                        value: document.getElementById('total').textContent.replace('$', '')
                    }
                }]
            });
        },
        onApprove: function (data, actions) {
            return actions.order.capture().then(function (detalles) {
                fetch('../api/api_captura_pago.php', {
                    method: 'post',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        detalles: detalles
                    })
                })
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Error en la respuesta del servidor');
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        alert(`La compra fue realizada exitosamente. ID de transacción: ${detalles.id}. Revise su email para más detalles.`);
                        window.location.reload(); // Refrescar la página
                    } else {
                        alert('Hubo un problema al registrar la compra. Por favor, intente nuevamente.');
                    }
                })
                .catch(error => {
                    console.error('Error al capturar el pago:', error);
                    alert('Hubo un error al procesar el pago.');
                });
            });
        },
        onCancel: function (data) {
            alert("Pago cancelado");
            console.log(data);
        }
    }).render('#paypal-button-container');
});
