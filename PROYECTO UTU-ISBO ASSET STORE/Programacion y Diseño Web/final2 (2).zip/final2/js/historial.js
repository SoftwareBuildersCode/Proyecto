document.addEventListener("DOMContentLoaded", function () {
    fetch('../api/api_historial_compras.php')
        .then(response => response.json())
        .then(data => {
            const historialContainer = document.querySelector('#historialCompras'); // Asegúrate de que el id es correcto en tu HTML.

            if (data.compras && data.compras.length > 0) {
                historialContainer.innerHTML = ''; // Limpiar contenido existente
                data.compras.forEach(compra => {
                    const total = parseFloat(compra.total); // Asegúrate de que sea un número
                    const card = document.createElement('div');
                    card.classList.add('col-12', 'mb-3'); // Asegúrate de que las tarjetas estén bien distribuidas
                    card.innerHTML = `
                        <div class="card text-white bg-dark">
                            <div class="card-header">
                                ${compra.fecha}
                            </div>
                            <div class="card-body">
                                <h5 class="card-title">ID transacción: ${compra.id_transaccion}</h5>
                                <p class="card-text">Total: $${!isNaN(total) ? total.toFixed(2) : '0.00'}</p>
                                
                            </div>
                        </div>
                    `;
                    historialContainer.appendChild(card);
                });
            } else {
                historialContainer.innerHTML = `<p class="text-center text-muted">No hay compras disponibles.</p>`;
            }
        })
        .catch(error => {
            console.error('Error al cargar el historial de compras:', error);
            alert('Hubo un problema al cargar el historial de compras.');
        });
});
