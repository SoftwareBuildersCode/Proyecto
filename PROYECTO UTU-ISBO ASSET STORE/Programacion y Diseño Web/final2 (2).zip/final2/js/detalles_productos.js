document.addEventListener("DOMContentLoaded", function () {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const token = params.get('token');

    if (!id || !token) {
        alert('Error al cargar la página: ID o token faltantes');
        return;
    }

    fetch(`../api/api_detalles_Productos.php?id=${id}&token=${token}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json();
        })
        .then(data => {
            if (data.error) {
                alert(data.error);
                return;
            }

            // Usar un valor por defecto para la moneda si no se envía desde el servidor
            const moneda = data.moneda || '$';

            // Actualizar el nombre del producto
            const productName = document.getElementById('productName');
            if (productName) {
                productName.textContent = data.nombre || 'Nombre no disponible';
            }

            // Actualizar el precio del producto
            const priceContainer = document.getElementById('productPriceContainer');
            if (priceContainer) {
                const precio = parseFloat(data.precio);
                const precioDescuento = parseFloat(data.precio_descuento);
                const descuento = parseFloat(data.descuento);

                if (!isNaN(precio)) {
                    if (descuento > 0 && !isNaN(precioDescuento)) {
                        priceContainer.innerHTML = `
                            <p><del>${moneda}${precio.toFixed(2)}</del></p>
                            <h2>${moneda}${precioDescuento.toFixed(2)}
                                <small class="text-success">${descuento}% descuento</small>
                            </h2>`;
                    } else {
                        priceContainer.innerHTML = `<h2>${moneda}${precio.toFixed(2)}</h2>`;
                    }
                } else {
                    priceContainer.textContent = 'Precio no disponible';
                }
            }

            // Actualizar la descripción del producto
            const productDescription = document.getElementById('productDescription');
            if (productDescription) {
                productDescription.textContent = data.descripcion || 'Descripción no disponible';
            }

            // Actualizar las imágenes del producto
            const carouselContent = document.getElementById('carouselContent');
            if (carouselContent) {
                carouselContent.innerHTML = `
                    <div class="carousel-item active">
                        <img src="${data.rutaImg || '../img/no-photo.jpg'}" class="d-block w-100" alt="Imagen principal del producto">
                    </div>`;
                if (Array.isArray(data.imagenes) && data.imagenes.length > 0) {
                    data.imagenes.forEach(img => {
                        const item = document.createElement('div');
                        item.classList.add('carousel-item');
                        item.innerHTML = `<img src="${img}" class="d-block w-100" alt="Imagen adicional del producto">`;
                        carouselContent.appendChild(item);
                    });
                }
            }

            // Actualizar las características del producto
            const characteristicsContainer = document.getElementById('productCharacteristics');
            if (characteristicsContainer) {
                if (Array.isArray(data.caracteristicas) && data.caracteristicas.length > 0) {
                    data.caracteristicas.forEach(caracteristica => {
                        const label = document.createElement('label');
                        label.textContent = `${caracteristica.caracteristica}: `;
                        characteristicsContainer.appendChild(label);

                        const select = document.createElement('select');
                        select.classList.add('form-select');
                        select.id = `cat_${caracteristica.idCat}`;

                        if (Array.isArray(caracteristica.valores) && caracteristica.valores.length > 0) {
                            caracteristica.valores.forEach(valor => {
                                const option = document.createElement('option');
                                option.value = valor.id;
                                option.textContent = valor.valor;
                                select.appendChild(option);
                            });
                        } else {
                            const option = document.createElement('option');
                            option.textContent = 'Sin opciones';
                            select.appendChild(option);
                        }

                        characteristicsContainer.appendChild(select);
                    });
                } else {
                    characteristicsContainer.textContent = 'No hay características disponibles';
                }
            }

            // Botón de agregar al carrito
            const addToCartButton = document.getElementById('addToCartButton');
            if (addToCartButton) {
                addToCartButton.onclick = function () {
                    agregarProducto(id, token);
                };
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los detalles del producto');
        });
});

function agregarProducto(id, token) {
    // Lógica para agregar el producto al carrito
    console.log(`Producto ${id} con token ${token} agregado al carrito`);
}
