document.addEventListener("DOMContentLoaded", function () {
    // Verificar si el usuario ha iniciado sesión
    fetch('../api/api_verificar_sesion.php')
        .then(response => response.json())
        .then(data => {
            const navContainer = document.querySelector('.navbar .container');
            const loginButton = document.querySelector('.btn.btn-sm.btn-secondary');

            if (data.logged_in) {
                // Si el usuario ha iniciado sesión, mostrar el nombre del usuario con un menú de opciones
                if (loginButton) {
                    loginButton.remove(); // Remover el botón de "Ingresar" existente
                }

                // Crear el menú desplegable de usuario
                const userDropdown = document.createElement('div');
                userDropdown.classList.add('dropdown');

                userDropdown.innerHTML = `
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="userMenu" data-bs-toggle="dropdown" aria-expanded="false">
                        ${data.username}
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="userMenu">
                        <li><a class="dropdown-item" href="historial.html">Historial de compras</a></li>
                        <li><a class="dropdown-item" href="../api/api_cerrar_sesion.php">Cerrar sesión</a></li>
                    </ul>
                `;

                navContainer.appendChild(userDropdown);
            } else {
                // Si no ha iniciado sesión, mostrar "Ingresar"
                if (loginButton) {
                    loginButton.textContent = "Ingresar";
                    loginButton.href = "login.html";
                }
            }
        })
        .catch(error => {
            console.error('Error al verificar la sesión:', error);
        });

    // Código existente para cargar productos
    fetch('../api/api_index.php')
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error al cargar la lista de productos');
                return;
            }

            const container = document.querySelector('.row.g-3');
            container.innerHTML = ''; // Limpiar contenido existente

            data.productos.forEach(producto => {
                const card = document.createElement('div');
                card.classList.add('col');
                card.innerHTML = `
                    <div class="card shadow-sm">
                        <img src="${producto.imagen}" alt="Producto">
                        <div class="card-body">
                            <h5 class="card-title">${producto.nombre}</h5>
                            <p class="card-text">$${producto.precio.toFixed(2)}</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="detalles_productos.html?id=${producto.id}&token=${producto.token}" class="btn btn-secondary">Detalles</a>
                                </div>
                                <button class="btn btn-outline-success" type="button" onclick="agregarProducto(${producto.id}, '${producto.token}')">Agregar al carrito</button>
                            </div>
                        </div>
                    </div>
                `;
                container.appendChild(card);
            });
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los productos');
        });
});

function agregarProducto(id, token) {
    // Lógica para agregar el producto al carrito
    console.log(`Producto ${id} con token ${token} agregado al carrito`);
}
