document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById('loginForm');

    loginForm.addEventListener('submit', function (event) {
        event.preventDefault();

        const formData = new FormData(loginForm);

        fetch('../api/api_login.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                return response.text().then(text => {
                    throw new Error('Error en la respuesta del servidor: ' + text);
                });
            }
            return response.json();
        })
        .then(data => {
            if (data.ok) {
                window.location.href = '../public/index.html'; // Redirigir si es exitoso
            } else {
                const errorMessages = document.getElementById('errorMessages');
                errorMessages.innerHTML = '';
                data.errors.forEach(error => {
                    const errorMessage = document.createElement('p');
                    errorMessage.textContent = error;
                    errorMessages.appendChild(errorMessage);
                });
                errorMessages.classList.remove('d-none');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Hubo un error al procesar la respuesta del servidor. Detalle: ' + error.message);
        });
    });
});
