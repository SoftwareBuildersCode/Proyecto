<?php
session_start(); // Asegúrate de tener session_start() al comienzo para acceder a la sesión actual
session_destroy(); // Destruye la sesión
header("Location: ../public/index.html"); // Redirige a la página de inicio
exit(); // Asegúrate de que el script se detenga después de redirigir
?>
