<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

try {
    $db = new Database();
    $con = $db->conectar();

    // Obtener las categorías activas
    $sql = $con->prepare("SELECT id, nombre FROM categorias WHERE activo = 1");
    $sql->execute();
    $categorias = $sql->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($categorias);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al obtener las categorías: ' . $e->getMessage()]);
}
?>
