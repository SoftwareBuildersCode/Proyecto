<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

$db = new Database();
$con = $db->conectar();

try {
    // Verificar si hay productos en el carrito
    $productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;

    if ($productos === null) {
        echo json_encode(['error' => 'El carrito está vacío.']);
        exit;
    }

    $lista_carrito = [];
    foreach ($productos as $clave => $cantidad) {
        // Obtener detalles del producto
        $sql = $con->prepare("SELECT id, nombre, precio, descuento, ? AS cantidad FROM productos WHERE id = ? AND activo = 1");
        $sql->execute([$cantidad, $clave]);
        $producto = $sql->fetch(PDO::FETCH_ASSOC);

        if ($producto) {
            $precio = $producto['precio'];
            $descuento = $producto['descuento'];
            $precio_descuento = $precio - (($precio * $descuento) / 100);
            $subtotal = $precio_descuento * $cantidad;

            $lista_carrito[] = [
                'id' => $producto['id'],
                'nombre' => $producto['nombre'],
                'precio_unitario' => $precio_descuento,
                'cantidad' => $cantidad,
                'subtotal' => $subtotal
            ];
        }
    }

    echo json_encode(['productos' => $lista_carrito]);
} catch (Exception $e) {
    echo json_encode(['error' => 'Error interno del servidor.']);
}
?>
