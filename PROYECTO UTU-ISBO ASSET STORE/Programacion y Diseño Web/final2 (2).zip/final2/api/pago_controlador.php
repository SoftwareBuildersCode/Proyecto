<?php
require '../config/config.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();

$productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;
$lista_carrito = [];

if ($productos != null) {
    foreach ($productos as $clave => $cantidad) {
        $sql = $con->prepare("SELECT id, nombre, precio, descuento, $cantidad AS cantidad FROM productos WHERE id = ? AND activo = 1");
        $sql->execute([$clave]);
        $lista_carrito[] = $sql->fetch(PDO::FETCH_ASSOC);
    }
} else {
    header("Location: ../public/index.php");
    exit;
}

$total = 0;
foreach ($lista_carrito as $producto) {
    $precio = $producto['precio'];
    $descuento = $producto['descuento'];
    $cantidad = $producto['cantidad'];
    $precio_descuento = $precio - (($precio * $descuento) / 100);
    $subtotal = $cantidad * $precio_descuento;
    $total += $subtotal;
}
