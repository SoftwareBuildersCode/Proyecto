<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

$db = new Database();
$con = $db->conectar();

$id_transaccion = isset($_GET['key']) ? $_GET['key'] : '0';
$response = [];

if ($id_transaccion == '') {
    $response['error'] = 'Error de petición';
} else {
    $sql = $con->prepare("SELECT count(id) FROM compra WHERE id_transaccion=? AND status=?");
    $sql->execute([$id_transaccion, 'COMPLETED']);

    if ($sql->fetchColumn() > 0) {
        $sql = $con->prepare("SELECT id, fecha, email, total FROM compra WHERE id_transaccion=? AND status=? LIMIT 1");
        $sql->execute([$id_transaccion, 'COMPLETED']);
        $row = $sql->fetch(PDO::FETCH_ASSOC);

        $idCompra = $row['id'];
        $response['id_transaccion'] = $id_transaccion;
        $response['total'] = $row['total'];
        $response['fecha'] = $row['fecha'];

        $sqlDet = $con->prepare("SELECT nombre, precio, cantidad FROM detalles_compra WHERE id_compra = ?");
        $sqlDet->execute([$idCompra]);
        $detalles = $sqlDet->fetchAll(PDO::FETCH_ASSOC);

        $response['detalles'] = $detalles;
    } else {
        $response['error'] = 'Error al comprobar la compra';
    }
}

echo json_encode($response);
?>
