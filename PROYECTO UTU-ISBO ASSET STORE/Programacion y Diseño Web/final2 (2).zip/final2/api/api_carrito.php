<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');

$db = new Database();
$con = $db->conectar();

$productos = isset($_SESSION['carrito']['productos']) ? $_SESSION['carrito']['productos'] : null;
$lista_carrito = [];

if ($productos != null) {
    foreach ($productos as $clave => $cantidad) {
        $sql = $con->prepare("SELECT id, nombre, precio, descuento, ? AS cantidad FROM productos WHERE id=? AND activo=1");
        $sql->execute([$cantidad, $clave]);
        $producto = $sql->fetch(PDO::FETCH_ASSOC);
        if ($producto) {
            $lista_carrito[] = $producto;
        }
    }
}

echo json_encode([
    'carrito' => $lista_carrito,
    'moneda' => MONEDA // Incluir la moneda para usar en el JavaScript
]);
?>
