<?php
header('Content-Type: application/json');

require '../config/config.php';
require '../config/database.php';
require 'api_clientes_funciones.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db = new Database();
$con = $db->conectar();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = array_map(fn($input) => trim($_POST[$input] ?? ''), ['nombre', 'apellido', 'email', 'telefono', 'cedula', 'usuario', 'password', 'repassword']);
    [$nombre, $apellido, $email, $telefono, $cedula, $usuario, $password, $repassword] = $data;

    if (esNulo($data)) {
        $errors[] = "Debe completar todos los campos";
    }
    if (!esEmail($email)) {
        $errors[] = "La dirección de correo $email no es válida";
    } elseif (correoExistente($email, $con)) {
        $errors[] = "La dirección de correo $email ya está registrada";
    }
    if (!validarPassword($password, $repassword)) {
        $errors[] = "Las contraseñas no coinciden";
    }
    if (usuarioExistente($usuario, $con)) {
        $errors[] = "El usuario $usuario ya está registrado";
    }

    if (empty($errors)) {
        $idCliente = registrarCliente([$nombre, $apellido, $email, $telefono, $cedula], $con);
        if ($idCliente > 0) {
            require 'Mailer.php';
            $mailer = new Mailer();
            $token = generarToken();
            $passHash = password_hash($password, PASSWORD_DEFAULT);
            $idUsuario = registrarUsuario([$usuario, $passHash, $token, $idCliente], $con);

            if ($idUsuario > 0) {
                $url = SITE_URL . "api/activar_cliente.php?id=$idUsuario&token=$token";
                $asunto = "Activar cuenta - ASSET Store";
                $cuerpo = "$nombre, <br> Para autenticar su cuenta haga click en el siguiente enlace <a href='$url'>Activar cuenta</a>";
                if ($mailer->enviarEmail($email, $asunto, $cuerpo)) {
                    echo json_encode(['ok' => true]);
                    exit;
                } else {
                    $errors[] = "Error al enviar el correo de activación";
                }
            } else {
                $errors[] = "Error al registrar usuario";
            }
        } else {
            $errors[] = "Error al registrar cliente";
        }
    }

    echo json_encode(['ok' => false, 'errors' => $errors]);
    exit;
}
?>
