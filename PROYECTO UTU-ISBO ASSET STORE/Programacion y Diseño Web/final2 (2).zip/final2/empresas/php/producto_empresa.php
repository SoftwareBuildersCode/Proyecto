<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_SESSION['empresa_id'])) {
        echo json_encode(['ok' => false, 'errors' => ['No se ha iniciado sesión correctamente.']]);
        exit;
    }

    $nombre = trim($_POST['nombre'] ?? '');
    $precio = trim($_POST['precio'] ?? '');
    $descuento = trim($_POST['descuento'] ?? '');
    $descripcion = trim($_POST['descripcion'] ?? '');
    $categoria = trim($_POST['categoria'] ?? '');
    $activo = trim($_POST['activo'] ?? '');

    if (empty($nombre) || empty($precio) || empty($descripcion) || empty($categoria) || $activo === '') {
        echo json_encode(['ok' => false, 'errors' => ['Todos los campos obligatorios deben completarse.']]);
        exit;
    }

    try {
        $db = new Database();
        $con = $db->conectar();
        $id_empresa = $_SESSION['empresa_id']; // ID de la empresa logueada

        $sql = $con->prepare("INSERT INTO productos (nombre, precio, descuento, descripcion, id_categoria, id_empresa, activo) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $sql->execute([$nombre, $precio, $descuento, $descripcion, $categoria, $id_empresa, $activo]);

        echo json_encode(['ok' => true]);
    } catch (Exception $e) {
        echo json_encode(['ok' => false, 'errors' => ['Error al subir el producto: ' . $e->getMessage()]]);
    }
}
?>
