<?php
header('Content-Type: application/json');
require '../config/config.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $rut = trim($_POST['rut'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $repassword = trim($_POST['repassword'] ?? '');

    if (empty($nombre) || empty($rut) || empty($telefono) || empty($email) || empty($direccion) || empty($password) || empty($repassword)) {
        $errors[] = "Debe completar todos los campos";
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "La dirección de correo $email no es válida";
    }

    if ($password !== $repassword) {
        $errors[] = "Las contraseñas no coinciden";
    }

    if (empty($errors)) {
        $passwordHash = password_hash($password, PASSWORD_DEFAULT);

        $sql = $con->prepare("INSERT INTO empresa (nombre, rut, telefono, email, direccion, password) VALUES (?, ?, ?, ?, ?, ?)");
        if ($sql->execute([$nombre, $rut, $telefono, $email, $direccion, $passwordHash])) {
            echo json_encode(['ok' => true]);
            exit;
        } else {
            $errors[] = "Error al registrar la empresa";
        }
    }

    echo json_encode(['ok' => false, 'errors' => $errors]);
}
?>
