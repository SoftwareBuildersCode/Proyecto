<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['empresa_id'])) {
    echo json_encode(['error' => 'No ha iniciado sesión.']);
    exit;
}

$empresa_id = $_SESSION['empresa_id'];
$db = new Database();
$con = $db->conectar();

$sql = $con->prepare("SELECT p.id, p.nombre, p.precio, p.descuento, p.descripcion, c.nombre AS categoria
                      FROM productos p
                      JOIN categorias c ON p.id_categoria = c.id
                      WHERE p.id_empresa = ?");
$sql->execute([$empresa_id]);
$productos = $sql->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(['productos' => $productos]);
?>
