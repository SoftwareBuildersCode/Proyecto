<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $db = new Database();
    $con = $db->conectar();

    $sql = $con->prepare("SELECT id, nombre FROM categorias WHERE activo = 1");
    $sql->execute();

    $categorias = $sql->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($categorias);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al obtener las categorías: ' . $e->getMessage()]);
}
?>
