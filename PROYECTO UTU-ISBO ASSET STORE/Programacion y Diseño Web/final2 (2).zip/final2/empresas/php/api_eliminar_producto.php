<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['empresa_id'])) {
    echo json_encode(['error' => 'No ha iniciado sesión.']);
    exit;
}

$empresa_id = $_SESSION['empresa_id'];
$id_producto = $_GET['id'] ?? null;

if (!$id_producto) {
    echo json_encode(['error' => 'ID de producto no válido.']);
    exit;
}

$db = new Database();
$con = $db->conectar();

$sql = $con->prepare("DELETE FROM productos WHERE id = ? AND id_empresa = ?");
$result = $sql->execute([$id_producto, $empresa_id]);

if ($result) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['error' => 'No se pudo eliminar el producto.']);
}
?>
