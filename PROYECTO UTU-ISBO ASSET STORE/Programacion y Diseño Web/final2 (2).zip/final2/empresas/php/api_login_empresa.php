<?php
header('Content-Type: application/json');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require '../config/config.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $empresa = trim($_POST['empresa'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($empresa) || empty($password)) {
        $errors[] = "Debe completar todos los campos.";
    }

    if (empty($errors)) {
        try {
            $sql = $con->prepare("SELECT id, nombre, password FROM empresa WHERE nombre = ? LIMIT 1");
            $sql->execute([$empresa]);
            $empresaData = $sql->fetch(PDO::FETCH_ASSOC);

            if ($empresaData && password_verify($password, $empresaData['password'])) {
                // Verificar si la sesión ya está activa antes de iniciarla
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                $_SESSION['empresa_id'] = $empresaData['id'];
                $_SESSION['empresa_nombre'] = $empresaData['nombre'];
                echo json_encode(['ok' => true]);
            } else {
                $errors[] = 'Nombre de empresa o contraseña incorrectos.';
            }
        } catch (Exception $e) {
            $errors[] = 'Error del servidor: ' . $e->getMessage();
        }
    }

    if (!empty($errors)) {
        echo json_encode(['ok' => false, 'errors' => $errors]);
    }
    exit;
}
