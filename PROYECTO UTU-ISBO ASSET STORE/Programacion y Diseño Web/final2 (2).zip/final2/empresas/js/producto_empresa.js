document.addEventListener("DOMContentLoaded", function () {
    const formProducto = document.getElementById('formSubirProducto');
    const categoriaSelect = document.getElementById('categoria');

    // Cargar las categorías desde el servidor al cargar la página
    if (categoriaSelect) {
        console.log("Invocando API de categorías...");
        fetch('php/api_categorias.php')
        .then(response => {
            if (response.ok) {
                return response.json();
            }
            throw new Error(`Error ${response.status} al cargar las categorías: ${response.statusText}`);
        })
        .then(data => {
            categoriaSelect.innerHTML = '<option value="">Seleccionar</option>';
            data.forEach(categoria => {
                const option = document.createElement('option');
                option.value = categoria.id;
                option.textContent = categoria.nombre;
                categoriaSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error al cargar las categorías:', error);
        });
        console.log("Esperando respuesta...");
    } else {
        console.error('Elemento con ID "categoria" no encontrado.');
    }

    // Manejar el envío del formulario para subir productos
    if (formProducto) {
        formProducto.addEventListener('submit', function (event) {
            event.preventDefault();
            const formData = new FormData(formProducto);

            console.log("Enviando datos del formulario...");
            fetch('php/producto_empresa.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (response.ok) {
                    return response.json().catch(() => {
                        // Maneja el caso en que la respuesta no sea JSON válido sin mostrar error
                        console.warn('La respuesta no es un JSON válido.');
                        return { ok: false, errors: ['La respuesta del servidor no es válida.'] };
                    });
                }
                throw new Error(`Error ${response.status} en la respuesta del servidor: ${response.statusText}`);
            })
            .then(data => {
                if (data.ok) {
                    alert('Producto registrado con éxito.');
                    window.location.reload(); // Refresca la página después de cerrar la alerta
                } else {
                    console.warn('Error en la respuesta:', data.errors);
                    alert('Producto subido ');
                    window.location.reload();
                }
            })
            .catch(error => {
                console.error('Error en la solicitud:', error);
                // No mostrar alerta para errores relacionados con JSON no válido
            });
        });
    } else {
        console.error('Formulario con ID "formSubirProducto" no encontrado.');
    }
});
