<?php
require '../config/config.php';
require '../config/database.php';
$db = new Database();
$con = $db->conectar();

header('Content-Type: application/json');

$id = isset($_GET['id']) ? $_GET['id'] : '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($id == '' || $token == '') {
    echo json_encode(['error' => 'Error al cargar la página']);
    exit;
} else {
    $token_tmp = hash_hmac('sha1', $id, KEY_TOKEN);
    if ($token == $token_tmp) {
        $sql = $con->prepare("SELECT count(id) FROM productos WHERE id=? AND activo=1");
        $sql->execute([$id]);

        if ($sql->fetchColumn() > 0) {
            $sql = $con->prepare("SELECT nombre, descripcion, precio, descuento FROM productos WHERE id=? AND activo=1");
            $sql->execute([$id]);
            $row = $sql->fetch(PDO::FETCH_ASSOC);

            $precio = $row['precio'];
            $descuento = $row['descuento'];
            $precio_descuento = $precio - (($precio * $descuento) / 100);
            $dir_images = '../img/productos/' . $id . '/';

            $rutaImg = $dir_images . 'producto.jpg';
            if (!file_exists($rutaImg)) {
                $rutaImg = '../img/no-photo.jpg';
            }

            $imagenes = [];
            if (is_dir($dir_images)) {
                $dir = dir($dir_images);
                while (($archivo = $dir->read()) !== false) {
                    if ($archivo != 'principal.jpg' && (strpos($archivo, 'jpg') || strpos($archivo, 'jpeg'))) {
                        $imagenes[] = $dir_images . $archivo;
                    }
                }
                $dir->close();
            }

            $sqlCaracter = $con->prepare("SELECT DISTINCT(det.id_carateristicas) AS idCat, caract.caracteristica 
                                          FROM det_productos_caracteristicas AS det 
                                          INNER JOIN caracteristicas AS caract ON det.id_carateristicas=caract.id
                                          WHERE det.id_producto=?");
            $sqlCaracter->execute([$id]);
            $caracteristicas = [];
            while ($row_cat = $sqlCaracter->fetch(PDO::FETCH_ASSOC)) {
                $idCat = $row_cat['idCat'];
                $caracteristicas[] = [
                    'idCat' => $idCat,
                    'caracteristica' => $row_cat['caracteristica'],
                    'valores' => []
                ];

                $sqlDet = $con->prepare("SELECT id, valor, stock FROM det_productos_caracteristicas WHERE id_producto=? AND id_carateristicas=?");
                $sqlDet->execute([$id, $idCat]);
                while ($row_det = $sqlDet->fetch(PDO::FETCH_ASSOC)) {
                    $caracteristicas[count($caracteristicas) - 1]['valores'][] = [
                        'id' => $row_det['id'],
                        'valor' => $row_det['valor']
                    ];
                }
            }

            echo json_encode([
                'nombre' => $row['nombre'],
                'descripcion' => $row['descripcion'],
                'precio' => $precio,
                'descuento' => $descuento,
                'precio_descuento' => $precio_descuento,
                'rutaImg' => $rutaImg,
                'imagenes' => $imagenes,
                'caracteristicas' => $caracteristicas,
                'moneda' => MONEDA // Incluyendo la constante MONEDA para su uso en el JS
            ]);
        } else {
            echo json_encode(['error' => 'Producto no encontrado']);
        }
    } else {
        echo json_encode(['error' => 'Error al cargar la página']);
    }
}
?>
