<?php
require '../config/config.php';
require '../config/database.php';

header('Content-Type: application/json');


$datos = ['ok' => false];

if (isset($_POST['action'])) {
    $action = $_POST['action'];
    $id = isset($_POST['id']) ? intval($_POST['id']) : 0; // Convertir a entero para mayor seguridad

    if ($id > 0) {
        $cantidad = isset($_POST['cantidad']) ? intval($_POST['cantidad']) : 0; // Convertir a entero

        $db = new Database();
        $con = $db->conectar();

        if ($action == 'agregar') {
            $respuesta = agregar($con, $id, $cantidad);
            if ($respuesta > 0) {
                $datos['ok'] = true;
                $datos['sub'] = MONEDA . number_format($respuesta, 2, '.', ',');
            } else {
                $datos['error'] = 'No se pudo agregar el producto';
            }
        } else if ($action == 'eliminar') {
            $datos['ok'] = eliminar($id);
            if (!$datos['ok']) {
                $datos['error'] = 'No se pudo eliminar el producto';
            }
        } else {
            $datos['error'] = 'Acción no válida';
        }
    } else {
        $datos['error'] = 'ID no válido';
    }
} else {
    $datos['error'] = 'No se recibió ninguna acción';
}

echo json_encode($datos);

function agregar($con, $id, $cantidad) {
    $res = 0;
    if ($cantidad > 0) {
        if (isset($_SESSION['carrito']['productos'][$id])) {
            $_SESSION['carrito']['productos'][$id] = $cantidad;

            $sql = $con->prepare("SELECT precio, descuento FROM productos WHERE id=? AND activo=1");
            $sql->execute([$id]);
            $row = $sql->fetch(PDO::FETCH_ASSOC);

            if ($row) {
                $precio = $row['precio'];
                $descuento = $row['descuento'];
                $precio_descuento = $precio - (($precio * $descuento) / 100);
                $res = $cantidad * $precio_descuento;
            }
        }
    }
    return $res;
}

function eliminar($id) {
    if (isset($_SESSION['carrito']['productos'][$id])) {
        unset($_SESSION['carrito']['productos'][$id]);
        return true;
    }
    return false;
}
?>
