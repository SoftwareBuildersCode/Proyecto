<?php
require '../config/config.php';
require '../config/database.php';
require 'api_clientes_funciones.php';

$db = new Database();
$con = $db->conectar();

$id_cliente = $_SESSION['user_cliente'] ?? null;
$compras = [];

if ($id_cliente) {
    $sql = $con->prepare("SELECT id_transaccion, fecha, status, total FROM compra WHERE id_cliente = ? ORDER BY DATE(fecha) DESC");
    $sql->execute([$id_cliente]);
    $compras = $sql->fetchAll(PDO::FETCH_ASSOC);

    foreach ($compras as &$compra) {
        $compra['token'] = hash_hmac('sha1', $compra['id_transaccion'], KEY_TOKEN); // Generar token para seguridad
    }
}

header('Content-Type: application/json');
echo json_encode(['compras' => $compras]);
?>
