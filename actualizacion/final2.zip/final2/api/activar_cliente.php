<?php
require '../config/config.php';
require '../config/database.php';
require 'api_clientes_funciones.php';

$id = isset($_GET['id']) ? $_GET['id'] : '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($id == '' || $token == '') {
    header("Location: ../public/index.html");
    exit;
}

$db = new Database();
$con = $db->conectar();

$resultado = validaToken($id, $token, $con);

if ($resultado === true) {
    // Mostrar una alerta y redirigir a login.html
    echo '<script>
            alert("Usuario activado correctamente. Serás redirigido al inicio de sesión.");
            window.location.href = "../public/login.html";
          </script>';
} else {
    // Mostrar un mensaje de error y redirigir al inicio
    echo '<script>
            alert("Hubo un error al activar el usuario o ya está activado.");
            window.location.href = "../public/index.html";
          </script>';
}
?>
