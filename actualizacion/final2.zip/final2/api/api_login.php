<?php
require '../config/config.php';
require '../config/database.php';
require 'api_clientes_funciones.php';

header('Content-Type: application/json');

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db = new Database();
$con = $db->conectar();

$proceso = isset($_GET['pago']) ? 'pago' : 'login';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $proceso = $_POST['proceso'] ?? 'login';

    if (esNulo([$usuario, $password])) {
        $errors[] = "Debe completar todos los campos.";
    }

    if (count($errors) === 0) {
        $resultado = login($usuario, $password, $con, $proceso);
        if ($resultado !== true) {
            $errors[] = $resultado;
        }
    }

    if (count($errors) > 0) {
        // Verificar si hay salida no esperada
        ob_start();
        echo json_encode(['ok' => false, 'errors' => $errors]);
        $output = ob_get_clean();
        
        if (strpos($output, '<') !== false) {
            http_response_code(500); // Error interno del servidor
            echo json_encode(['ok' => false, 'errors' => ['Error interno del servidor.']]);
        } else {
            echo $output;
        }
    } else {
        echo json_encode(['ok' => true]);
    }
} else {
    http_response_code(405); // Método no permitido
    echo json_encode(['ok' => false, 'errors' => ['Método no permitido.']]);
}
?>
