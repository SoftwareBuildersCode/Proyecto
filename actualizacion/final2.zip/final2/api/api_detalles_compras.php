<?php
session_start(); // Asegúrate de que la sesión esté iniciada

header('Content-Type: application/json');

require '../config/config.php';
require '../config/database.php';
require 'api_clientes_funciones.php';

// Verifica si la clave 'token' existe en la sesión antes de usarla
if (!isset($_SESSION['token'])) {
    echo json_encode(['error' => 'Token de sesión no definido.']);
    exit;
}

$orden = $_GET['orden'] ?? null;
$token = $_GET['token'] ?? null;

// Verifica si el token de la URL coincide con el token de la sesión
if ($orden == null || $token == null || $token != $_SESSION['token']) {
    echo json_encode(['error' => 'Datos de la transacción no válidos.']);
    exit;
}

$db = new Database();
$con = $db->conectar();

$sqlCompra = $con->prepare("SELECT id, id_transaccion, fecha, total FROM compra WHERE id_transaccion = ? LIMIT 1");
$sqlCompra->execute([$orden]);
$rowCompra = $sqlCompra->fetch(PDO::FETCH_ASSOC);

if (!$rowCompra) {
    echo json_encode(['error' => 'No se encontró la compra.']);
    exit;
}

$id_compra = $rowCompra['id'];

$sqlDetalles = $con->prepare("SELECT nombre, precio, cantidad FROM detalles_compra WHERE id_compra = ?");
$sqlDetalles->execute([$id_compra]);
$detalles = $sqlDetalles->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'id_transaccion' => $rowCompra['id_transaccion'],
    'fecha' => $rowCompra['fecha'],
    'total' => $rowCompra['total'],
    'moneda' => defined('MONEDA') ? MONEDA : '$',
    'detalles' => $detalles
]);
?>
