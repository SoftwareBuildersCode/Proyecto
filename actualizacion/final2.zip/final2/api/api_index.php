<?php

require '../config/config.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();

// Obtener los productos
$sql = $con->prepare("SELECT id, nombre, precio FROM productos WHERE activo=1");
$sql->execute();
$resultado = $sql->fetchAll(PDO::FETCH_ASSOC);

$productos = [];
foreach ($resultado as $row) {
    $id = $row['id'];
    $imagen = "../img/productos/$id/producto.jpg";

    if (!file_exists($imagen)) {
        $imagen = "../img/no-photo.jpg";
    }

    $productos[] = [
        'id' => $id,
        'nombre' => $row['nombre'],
        'precio' => (float)$row['precio'],
        'imagen' => $imagen,
        'token' => hash_hmac('sha1', $id, KEY_TOKEN)
    ];
}

// Verificar si el usuario ha iniciado sesión y agregar el nombre de usuario
$username = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : null;

header('Content-Type: application/json');
echo json_encode([
    'productos' => $productos,
    'username' => $username
]);
?>
