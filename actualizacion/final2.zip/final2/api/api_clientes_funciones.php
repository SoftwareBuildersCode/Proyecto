<?php
function esNulo(array $parametros){
    foreach($parametros as $parametro){
        if(strlen(trim($parametro)) < 1){
            return true;
        }
    }
    return false;
}

function esEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

function validarPassword($password, $repassword){
    return strcmp($password, $repassword) === 0;
}

function generarToken() {
    return md5(uniqid(mt_rand(), false));
}

function registrarCliente(array $datos, $con) {
    $sql = $con->prepare("INSERT INTO clientes (nombre, apellido, email, telefono, cedula, estatus, fecha_alta) VALUES(?,?,?,?,?, 1, now())");
    return $sql->execute($datos) ? $con->lastInsertId() : 0;
}

function registrarUsuario(array $datos, $con) {
    $sql = $con->prepare("INSERT INTO usuarios (usuario, password, token, id_cliente) VALUES(?,?,?,?)");
    return $sql->execute($datos) ? $con->lastInsertId() : 0;
}

function usuarioExistente($usuario, $con) {
    $sql = $con->prepare("SELECT id FROM usuarios WHERE usuario = ? LIMIT 1");
    $sql->execute([$usuario]);
    return $sql->fetchColumn() > 0;
}

function correoExistente($email, $con) {
    $sql = $con->prepare("SELECT id FROM clientes WHERE email = ? LIMIT 1");
    $sql->execute([$email]);
    return $sql->fetchColumn() > 0;
}

function validaToken($id, $token, $con) {
    $sql = $con->prepare("SELECT id FROM usuarios WHERE id = ? AND token = ? LIMIT 1");
    $sql->execute([$id, $token]);
    return $sql->fetchColumn() > 0 ? activarUsuario($id, $con) : "Error del servidor";
}

function activarUsuario($id, $con) {
    $sql = $con->prepare("UPDATE usuarios SET activo = 1 WHERE id = ?");
    return $sql->execute([$id]);
}

function login($usuario, $password, $con, $proceso) {
    $sql = $con->prepare("SELECT id, usuario, password, id_cliente FROM usuarios WHERE usuario = ? LIMIT 1");
    $sql->execute([$usuario]);
    if ($row = $sql->fetch(PDO::FETCH_ASSOC)) {
        if (esActivo($usuario, $con) && password_verify($password, $row['password'])) {
            // Establecer la sesión sin redirigir directamente
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['usuario'];
            $_SESSION['user_cliente'] = $row['id_cliente'];
            
            // Retornar una señal JSON que indique que el login fue exitoso
            return true;
        }
        return 'El usuario no ha sido verificado.';
    }
    return 'El usuario o contraseña son incorrectos.';
}

function esActivo($usuario, $con) {
    $sql = $con->prepare("SELECT activo FROM usuarios WHERE usuario = ? LIMIT 1");
    $sql->execute([$usuario]);
    $row = $sql->fetch(PDO::FETCH_ASSOC);
    return $row['activo'] == 1;
}

function soliPassword($user_id, $con) {
    $token = generarToken();
    $sql = $con->prepare("UPDATE usuarios SET token_password = ?, password_request = 1 WHERE id = ?");
    return $sql->execute([$token, $user_id]) ? $token : null;
}

function verificaToken($user_id, $token, $con) {
    $sql = $con->prepare("SELECT id FROM usuarios WHERE id = ? AND token_password = ? AND password_request = 1 LIMIT 1");
    $sql->execute([$user_id, $token]);
    return $sql->fetchColumn() > 0;
}

function actu_password($user_id, $pass_hash, $con) {
    $sql = $con->prepare("UPDATE usuarios SET password = ?, token_password = '', password_request = 0 WHERE id = ?");
    return $sql->execute([$pass_hash, $user_id]);
}
?>
