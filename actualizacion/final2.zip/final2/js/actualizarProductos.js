document.addEventListener("DOMContentLoaded", function () {
    fetch('../api/api_carrito.php')
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json();
        })
        .then(data => {
            const carrito = data.carrito;
            const moneda = data.moneda || '$';
            const tableBody = document.querySelector('table tbody');
            let total = 0;

            if (carrito.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="5" class="text-center"><b>Vacio</b></td></tr>';
            } else {
                tableBody.innerHTML = ''; // Limpiar el contenido existente
                carrito.forEach(producto => {
                    const { id, nombre, precio, descuento, cantidad } = producto;
                    const precioDescuento = precio - ((precio * descuento) / 100);
                    const subtotal = cantidad * precioDescuento;
                    total += subtotal;

                    const row = `
                        <tr>
                            <td>${nombre}</td>
                            <td>${moneda}${precioDescuento.toFixed(2)}</td>
                            <td>
                                <input type="number" min="1" max="10" step="1" value="${cantidad}"
                                    size="5" id="cantidad_${id}" onchange="actualizar(this.value, ${id})">
                            </td>
                            <td>
                                <div id="subtotal_${id}" name="subtotal[]">${moneda}${subtotal.toFixed(2)}</div>
                            </td>
                            <td>
                                <button class="btn btn-danger btn-sm" onclick="eliminar(${id})">Eliminar</button>
                            </td>
                        </tr>
                    `;
                    tableBody.insertAdjacentHTML('beforeend', row);
                });

                const totalRow = `
                    <tr>
                        <td colspan="3"></td>
                        <td colspan="2">
                            <p class="h3" id="total">${moneda}${total.toFixed(2)}</p>
                        </td>
                    </tr>
                `;
                tableBody.insertAdjacentHTML('beforeend', totalRow);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error al cargar los productos del carrito');
        });
});

function actualizar(cantidad, id) {
    let url = '../api/api_actualizar_productos.php';
    let formData = new FormData();
    formData.append('action', 'agregar');
    formData.append('id', id);
    formData.append('cantidad', cantidad);

    fetch(url, {
        method: 'POST',
        body: formData,
        mode: 'cors'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.ok) {
            let divsubtotal = document.getElementById('subtotal_' + id);
            divsubtotal.innerHTML = data.sub;

            let total = 0.00;
            let list = document.getElementsByName('subtotal[]');

            for (let i = 0; i < list.length; i++) {
                let subtotal = parseFloat(list[i].innerHTML.replace(/[^0-9.-]+/g, ''));
                if (!isNaN(subtotal)) {
                    total += subtotal;
                }
            }

            let moneda = data.moneda || '$';
            total = new Intl.NumberFormat('en-US', {
                minimumFractionDigits: 2
            }).format(total);
            document.getElementById('total').innerHTML = moneda + total;
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}

function eliminar(id) {
    let url = '../api/api_actualizar_productos.php';
    let formData = new FormData();
    formData.append('action', 'eliminar');
    formData.append('id', id);

    fetch(url, {
        method: 'POST',
        body: formData,
        mode: 'cors'
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return response.json();
    })
    .then(data => {
        if (data.ok) {
            // Eliminar la fila del producto de la tabla
            document.querySelector(`button[onclick="eliminar(${id})"]`).closest('tr').remove();
            // Recalcular el total después de eliminar el producto
            let total = 0.00;
            let list = document.getElementsByName('subtotal[]');

            for (let i = 0; i < list.length; i++) {
                let subtotal = parseFloat(list[i].innerHTML.replace(/[^0-9.-]+/g, ''));
                if (!isNaN(subtotal)) {
                    total += subtotal;
                }
            }

            let moneda = data.moneda || '$';
            total = new Intl.NumberFormat('en-US', {
                minimumFractionDigits: 2
            }).format(total);
            document.getElementById('total').innerHTML = moneda + total;

            if (list.length === 0) {
                document.querySelector('table tbody').innerHTML = '<tr><td colspan="5" class="text-center"><b>Vacio</b></td></tr>';
            }
        } else {
            console.error('Error en la respuesta:', data.error);
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
}
