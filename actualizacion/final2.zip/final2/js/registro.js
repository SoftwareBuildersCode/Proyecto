document.addEventListener("DOMContentLoaded", function () {
    const registroForm = document.getElementById('registroForm');

    registroForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Evitar el envío del formulario

        const formData = new FormData(registroForm);

        fetch('../api/api_registro.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor');
            }
            return response.json();
        })
        .then(data => {
            if (data.ok) {
                alert('Registro exitoso. Revisa tu correo electrónico para activar tu cuenta.');
                window.location.href = 'login.html'; // Redirigir a la página de inicio de sesión
            } else {
                const errorMessages = document.getElementById('errorMessages');
                errorMessages.innerHTML = '';
                data.errors.forEach(error => {
                    const errorMessage = document.createElement('p');
                    errorMessage.textContent = error;
                    errorMessages.appendChild(errorMessage);
                });
                errorMessages.classList.remove('d-none');
            }
        })
    });
});
