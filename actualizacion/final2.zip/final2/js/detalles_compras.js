document.addEventListener("DOMContentLoaded", function () {
    const urlParams = new URLSearchParams(window.location.search);
    const orden = urlParams.get('orden');
    const token = urlParams.get('token');

    if (!orden || !token) {
        alert('Datos de la transacción no válidos.');
        window.location.href = 'historial.html';
        return;
    }

    fetch(`../api/api_detalles_compras.php?orden=${orden}&token=${token}`)
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                alert('Error al cargar los detalles de la compra.');
                return;
            }

            const detallesContainer = document.getElementById('detallesCompraContainer');
            const compraCard = `
                <div class="col-12 col-md-4">
                    <div class="card mb-3">
                        <div class="card-header">
                            <strong>Detalles de la compra</strong>
                        </div>
                        <div class="card-body">
                            <p><strong>Fecha: </strong>${data.fecha}</p>
                            <p><strong>ID Orden: </strong>${data.id_transaccion}</p>
                            <p><strong>Total: </strong>${data.moneda}${parseFloat(data.total).toFixed(2)}</p>
                        </div>
                    </div>
                </div>
            `;
            detallesContainer.innerHTML = compraCard;

            let tableHTML = `
                <div class="col-12 col-md-8">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Producto</th>
                                    <th>Precio</th>
                                    <th>Cantidad</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
            `;

            data.detalles.forEach(detalle => {
                const subtotal = detalle.precio * detalle.cantidad;
                tableHTML += `
                    <tr>
                        <td>${detalle.nombre}</td>
                        <td>${data.moneda}${detalle.precio.toFixed(2)}</td>
                        <td>${detalle.cantidad}</td>
                        <td>${data.moneda}${subtotal.toFixed(2)}</td>
                    </tr>
                `;
            });

            tableHTML += `
                            </tbody>
                        </table>
                    </div>
                </div>
            `;

            detallesContainer.innerHTML += tableHTML;
        })
        .catch(error => {
            console.error('Error al cargar los detalles de la compra:', error);
            alert('Hubo un problema al cargar los detalles de la compra.');
        });
});
