paypal.Buttons({
    style: {
        color: 'blue',
        shape: 'pill',
        label: 'pay'
    },
    createOrder: function(data, actions) {
        return actions.order.create({
            purchase_units: [{
                amount: {
                    value: <?php echo $total; ?>
                }
            }]
        });
    },
    onApprove: function(data, actions){
        let URL = '../clases/captura.php';
        actions.order.capture().then(function(detalles) {
        let urlCaptura = '../clases/captura.php';
            return fetch(urlCaptura, {
                method: 'post',
                headers: {
                    'content-type': 'application/json'
                },
                body: JSON.stringify({
                    detalles: detalles
                })
            }).then(function(response){
                window.location.href = "../completado.php?key=" + detalles['id'];

            })
        });
    },

    onCancel: function(data){
        alert("Pago cancelado");
        console.log(data)
    }
}).render('#paypal-button-container');