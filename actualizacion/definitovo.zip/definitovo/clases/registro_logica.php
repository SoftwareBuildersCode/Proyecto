<?php
require 'config/config.php';
require 'config/database.php';
require 'controladores/clientes_funciones.php';
$db = new Database();
$con = $db->conectar();

$errors=[];
if (!empty($_POST)) {
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $telefono = trim($_POST['telefono']);
    $cedula = trim($_POST['cedula']);
    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['password']);
    $repassword = trim($_POST['repassword']);
    
    if (esNulo([$nombre, $apellido, $email, $telefono, $cedula, $usuario, $password, $repassword])) {
        $errors[] = "Debe completar todos los campos";
    }
    
    if (!esEmail($email)) {
        $errors[] = "La dirección de correo $email no es válida";
    } elseif (correoExistente($email, $con)) {
        $errors[] = "La dirección de correo $email ya está registrada";
    }
    
    if (!validarPassword($password, $repassword)) {
        $errors[] = "Las contraseñas no coinciden";
    }
    
    if (usuarioExistente($usuario, $con)) {
        $errors[] = "El usuario $usuario ya está registrado";
    }
    
    if (count($errors) == 0) {
        $id = registrarCliente([$nombre, $apellido, $email, $telefono, $cedula], $con);
        if ($id > 0) {
            require 'controladores/config_mail.php';
            $mailer = new Mailer();
            $token = generarToken();
            $pass_hash = password_hash($password, PASSWORD_DEFAULT);
            $idUsuario = registrarUsuario([$usuario, $pass_hash, $token, $id], $con);
            if ($idUsuario > 0) {
                $url = SITE_URL . 'controladores/activar_clientes.php?id=' . $idUsuario . '&token=' . $token;
                $asunto = "Activar cuenta - ASSET Store";
                $cuerpo = "$nombre, <br> Para autenticar su cuenta haga click en el siguiente enlace <a href='$url'>Activar cuenta</a>";
                if ($mailer->enviarEmail($email, $asunto, $cuerpo)) {
                    echo "Para terminar el registro revise su correo: $email";
                    exit;
                }
            } else {
                $errors[] = "Error al registrar usuario";
            }
        } else {
            $errors[] = "Error al registrar cliente";
        }
    }
}

?>