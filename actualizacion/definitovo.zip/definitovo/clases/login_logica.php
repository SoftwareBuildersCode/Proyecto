<?php
require 'config/config.php';
require 'config/database.php';
require 'controladores/clientes_funciones.php';
$db = new Database();
$con = $db->conectar();
$proceso = isset($_GET['pago']) ? 'pago' : 'login';
$errors=[];
if(!empty($_POST)){
    $usuario = trim($_POST['usuario']);
    $password = trim($_POST['password']);
    $proceso = $_POST['proceso'] ?? 'login';
    if(esNulo([$usuario,$password])){
        $errors[ ] = "Debe complentar todos los campos ";

    }
    if(count($errors) == 0){
    $errors[] = login($usuario, $password, $con, $proceso);
}
}

?>