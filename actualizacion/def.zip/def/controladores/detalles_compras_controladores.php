<?php
require 'config/config.php';
require 'config/database.php';
require 'clientes_funciones.php';

$token_session = $_SESSION['token'];
$orden = $_GET['orden'] ?? null;
$token = $_GET['token'] ?? null;

if($orden == null || $token == null || $token != $token_session){
    header("Location: histo_compras.php");
    exit;
}
$db = new Database();
$con = $db->conectar();

$sqlCompra = $con->prepare("SELECT id, id_transaccion, fecha, total FROM compra WHERE id_transaccion = ? LIMIT 1");
$sqlCompra->execute([$orden]);
$rowCompra = $sqlCompra->fetch(PDO::FETCH_ASSOC);
$id_compra = $rowCompra['id'];

$fecha = new DateTime($rowCompra['fecha']);
$fecha =

$sqlDetalles = $con->prepare("SELECT id, nombre, precio, cantidad FROM detalles_compra WHERE id_compra = ?");
$sqlDetalles->execute([$id_compra]);

?>