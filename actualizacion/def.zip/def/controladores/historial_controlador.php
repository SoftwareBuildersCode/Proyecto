<?php
require 'config/config.php';
require 'config/database.php';
require 'clientes_funciones.php';

$db = new Database();
$con = $db->conectar();

$token = generarToken();
$_SESSION['token'] = $token; //genero dos token para mas seguridad

$id_cliente = $_SESSION['user_cliente'];
$sql = $con->prepare("SELECT id_transaccion, fecha, status, total FROM compra WHERE id_cliente=? ORDER BY DATE(fecha) DESC");
$sql->execute([$id_cliente]);
?>