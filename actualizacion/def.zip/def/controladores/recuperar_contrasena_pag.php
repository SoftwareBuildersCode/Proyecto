<?php require 'recuperar_contrasena.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tienda Online</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="../css/styles.css" rel="stylesheet">
    
</head>
<body>
<?php require '../menu.php'; ?>
<main class="form-login m-auto pt-4">
   <h3>Recuperar contraseña</h3>

   <?php echo mensajes($errors); ?>

    <form action="recuperar_contrasena.php" method="post" class="row g-3" autocomplete="off">
        <div class="form-floating">
            <input class="form-control" type="email" name="email" id="email" placeholder="Correo electronico" required>
            <label for="email">Correo electronico:</label>
        </div>

        <div class="d-grid gap-3 col-12">
            <button type="submit" class="btn btn-success">Solicitar cambio</button>
        </div>

        <hr>
        <div class="col-12">
            No tienes cuenta? <a href="registro.php">Registrate</a>
        </div>
    </form>
</main>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" 
integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
<script src="https://kit.fontawesome.com/348f0f7040.js" crossorigin="anonymous"></script>
</body>
</html>