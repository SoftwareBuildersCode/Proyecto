<?php
require '../config/config.php';
require '../config/database.php';
require 'clientes_funciones.php';
$db = new Database();
$con = $db->conectar();

$errors=[];

if(!empty($_POST)){
    $email = trim($_POST['email']);

    if(esNulo([$email])){
        $errors[ ] = "Debe complentar todos los campos ";
    }
    if(!esEmail($email)){
        $errors[] = "La direccion de correo $email no es valida";
    }
    if(count($errors)== 0){
        if(correoExistente($email, $con)){
            $sql = $con->prepare("SELECT usuarios.id, clientes.nombre FROM usuarios INNER JOIN clientes ON usuarios.id_cliente = clientes.id WHERE clientes.email LIKE ? LIMIT 1");

            $sql->execute([$email]);
            $row = $sql->fetch(PDO::FETCH_ASSOC);
            $user_id = $row['id'];
            $nombre = $row['nombre'];

            $token = soliPassword($user_id, $con);

            if($token !== null ){
                require '../clases/enviar_email.php';
                $mailer = new Mailer();

                $url = SITE_URL . '/reset_password.php?id=' . $user_id . '&token=' . $token;

                $asunto = "Recuperar contraseña - ASSET Store";
                $cuerpo = "$nombre, <br> Si ha solicitado el cambio de su contraseña, siga el siguiente enlace: <a href='$url'>$url</a>.";
                $cuerpo .= "<br>Si usted no hizo esta solicitud, por favor ignore este correo.";

                if($mailer->enviarEmail($email, $asunto, $cuerpo)){
                    echo "<p><b>Correo enviado </b></p>";
                    echo "<p><b>Enviamos un correo a $email para restablecer la contraseña</b></p>";
                    exit;
                }
            }
        }else{
            $errors[] = "No existe una cuenta en este corro";
        }
    }
}

?>