<?php

require '../clases/adminFunciones.php';
require '../config/database.php';

$db = new Database();
$con = $db->conectar();

$password = password_hash('admin', PASSWORD_DEFAULT);
$sql = "INSERT INTO admin (usuario, password, nombre, email, activo, fecha_alta"


?>